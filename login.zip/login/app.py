# Store this code in 'app.py' file
 
from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re
import secrets
import math
from pathlib import Path
 
 
app = Flask(__name__)
if __name__ == "__main__":
    app.run()
 
#app.secret_key = 'your secret key'
SECRET_FILE_PATH = Path(".flask_secret")
try:
    with SECRET_FILE_PATH.open("r") as secret_file:
        app.secret_key = secret_file.read()
except FileNotFoundError:
    # Let's create a cryptographically secure code in that file
    with SECRET_FILE_PATH.open("w") as secret_file:
        app.secret_key = secrets.token_hex(32)
        secret_file.write(app.secret_key)
#end of app.secret_key code
 
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = '@Prem1995'
app.config['MYSQL_DB'] = 'geeklogin'
 
mysql = MySQL(app)

#total_bal=0
@app.route('/')
@app.route('/login', methods =['GET', 'POST'])
def login():
    #global total_bal
    msg = ''
    g=4
    p=2
    q=3
    n=p*q
    h=pow(g,p)				#compute h=g power p

    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = % s AND password = % s', (username, password, ))
        account = cursor.fetchone()

        if username=='prem' and password=='1995' and account['position']=='Banker':
            session['loggedin'] = True
            session['id'] = account['id']
            session['username'] = account['username']
            session['cipher1'] =account['cust_cipher']
            msg = 'Logged in successfully!'
            return render_template('Banker.html', msg = msg)
        elif username=='Prem Kant' and password=='1234' and account['position']=='Customer':
            session['loggedin'] = True
            session['id'] = account['id']
            session['username'] = account['username']
            #Total After money is added in customer's account 
            ciphertotal2=int(float(account['t_cipher'])) 
            c_p2=pow(ciphertotal2,p)
            mess2=0	
            if c_p2>0:
    		        mess2=round(math.log(c_p2,h))#%(n)   #m=(log of c_p base g_p) % n  
            session['t_bal'] = mess2
            msg = 'Logged in successfully !'
            return render_template('index.html', msg = msg)
        else:
            msg = 'Incorrect username / password !'
    return render_template('login.html', msg = msg)
 
@app.route('/logout')
def logout():
    session.pop('loggedin', None)
    session.pop('id', None)
    session.pop('p', None)
    session.pop('q', None)
    session.pop('g', None)
    session.pop('n', None)
    session.pop('money', None)
    session.pop('cipher1', None)
    session.pop('mess1', None)
    session.pop('username', None)
    session.pop('cust_cipher', None)
    session.pop('t_cipher', None)
    return redirect(url_for('login'))
 
@app.route('/register', methods =['GET', 'POST'])
def register():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form and 'position' in request.form:
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']
        cust_cipher="2"
        t_cipher="2"
        position= request.form['position']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = % s', (username, ))
        account = cursor.fetchone()
        if account:
            msg = 'Account already exists !'
        elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
            msg = 'Invalid email address !'
        elif not re.match(r'[A-Za-z0-9]+', username):
            msg = 'Username must contain only characters and numbers !'
        elif not username or not password or not email:
            msg = 'Please fill out the form !'
        else:
            cursor.execute('INSERT INTO accounts VALUES (NULL,%s, % s, % s,%s,%s, % s)', (username, password, email,cust_cipher,t_cipher,position, ))
            mysql.connection.commit()
            msg = 'You have successfully registered !'
    elif request.method == 'POST':
        msg = 'Please fill out the form !'
    return render_template('register.html', msg = msg)

"""@app.route('/CustSearch', methods =['GET', 'POST'])
def register():
    msg = ''
    if request.method == 'POST' and 'username' in request.form:
        username = request.form['username']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = % s', (username, ))
        account = cursor.fetchone()
        session['custSearch']=account['cust_cipher']
    return render_template('Banker.html')"""

@app.route('/index', methods =['GET', 'POST'])
def index():
    #global total_bal
    enc = ''
    username='Prem Kant'
    g=4
    p=2
    q=3
    n=p*q
    h=pow(g,p)				#compute h=g power p

    if request.method == 'POST' and 'money' in request.form:
        money = int(request.form['money'])
    elif request.method == 'POST':
        enc = 'Please enter your money !'
    session['money'] = money
    cipher1 =pow(g,money)
    session['cipher1'] =cipher1 #compute c=g power money
    c_p=pow(cipher1,p)		      #compute cp=c power p
    mess1=0																				
    if c_p>0:
    	mess1=round(math.log(c_p,h))#%(n)    #m=(log of c_p base g_p) % n 
    #total_bal+=mess1 
    session['mess1'] = mess1

    # mysql details
    cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    cursor.execute('SELECT * FROM accounts WHERE username = % s', (username, ))
    account = cursor.fetchone()
    if account:
    		cursor.execute("UPDATE accounts SET cust_cipher =%s WHERE username ='Prem Kant'",(str(cipher1),))
    		mysql.connection.commit()
    return render_template('index.html',enc=enc)

@app.route('/Banker', methods =['GET', 'POST'])
def Banker():
    enc = ''
    g=4
    p=2
    q=3
    n=p*q
    h=pow(g,p)				#compute h=g power p

    if request.method == 'POST' and 'username' in request.form and 'operation' in request.form:
        username = request.form['username']
        operation= request.form['operation']
	
    #mysql commands to insert data

        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = % s', (username, ))
        account = cursor.fetchone()
        cust_cipher=int(account['cust_cipher'])
        total_cipher=int(float(account['t_cipher']))
        if operation=='Add':
                total_cipher *= cust_cipher     #compute ct=(c*c2)
        elif operation=='Subtract':
                total_cipher /= cust_cipher     #compute ct=(c/c2)
        else:
                enc = 'Please select operation !'   
        session['t_cipher'] = total_cipher
        session['cust_cipher'] =cust_cipher   #compute c=g power money
        if account:
    		    cursor.execute("UPDATE accounts SET t_cipher =%s ,cust_cipher =%s where username=%s",(str(total_cipher),"1",username,))
    		    mysql.connection.commit()
        else:
                enc = 'Incorrect Customer Name !'   
    elif request.method == 'POST':
        enc = 'Please fill all fields !'
    return render_template('Banker.html',enc=enc)